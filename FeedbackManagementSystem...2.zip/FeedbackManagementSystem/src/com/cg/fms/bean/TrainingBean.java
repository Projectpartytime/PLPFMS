package com.cg.fms.bean;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/* Name                                      Null?    Type
 ----------------------------------------- -------- ----------------
 TRAINING_CODE                             NOT NULL NUMBER(5)
 COURSE_CODE                                        NUMBER(5)
 FACULTY_CODE                                       NUMBER(5)
 START_DATE                                         DATE
 END_DATE                                           DATE*/
@Entity
@Table(name="TRAINING_MASTER")
public class TrainingBean
{
	@Id
//	@NotNull(message="TrainingCode cannot be blank")
//	@Pattern(message="TrainingCode should be in digits",regexp="[1-9][0-9]+")
	@Column(name="TRAINING_CODE")
	private long trainingCode;
	@Column(name="COURSE_CODE")
	private long courseCode;
	@Column(name="FACULTY_CODE")
	private long facultyCode;
	@Column(name="START_DATE")
	private LocalDate startDate;
	@Column(name="END_DATE")
	private LocalDate endDate;

	public long getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(long trainingCode) {
		this.trainingCode = trainingCode;
	}
	public long getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(long courseCode) {
		this.courseCode = courseCode;
	}
	public long getFacultyCode() {
		return facultyCode;
	}
	public void setFacultyCode(long facultyCode) {
		this.facultyCode = facultyCode;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
}
