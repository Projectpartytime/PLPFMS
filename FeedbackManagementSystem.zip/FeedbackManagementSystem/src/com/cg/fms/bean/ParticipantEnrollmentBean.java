package com.cg.fms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/*
 *  Name                                      Null?    Type
 ----------------------------------------- -------- ---------------------------

 TRAINING_CODE                                      NUMBER(5)
 PARTICIPANT_ID                                     NUMBER(5)
 */
@Entity
@Table(name="PARTICIPANT_ENROLLMENT")
public class ParticipantEnrollmentBean 
{
	@Column(name="TRAINING_CODE")
	private long trainingCode;
	@Column(name="PARTICIPANT_ID")
	private long participantId;

	public long getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(long trainingCode) {
		this.trainingCode = trainingCode;
	}
	public long getParticipantId() {
		return participantId;
	}
	public void setParticipantId(long participantId) {
		this.participantId = participantId;
	}


}
