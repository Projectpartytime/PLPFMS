package com.cg.fms.service;

public interface IFmsService {
	
	
}
