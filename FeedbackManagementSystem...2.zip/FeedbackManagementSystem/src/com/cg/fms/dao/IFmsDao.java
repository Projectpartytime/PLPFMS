package com.cg.fms.dao;

import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;


public interface IFmsDao 
{
	long insertFeedback(FeedbackBean feedback);
	
	
	List<Long> validateGetAllTrainingIds();
	List<Long> validateGetAllParticipantIds();
	
	List<Long> validateGetAllEnrolledTrainingIds();
	List<Long> validateGetAllEnrolledParticipantIds(long trainingId);
	
	List<Long> validateGetAllFeedBackTrainingIds();
	List<Long> validateGetAllFeedBackParticipanIds(long trainingId);
	
}
