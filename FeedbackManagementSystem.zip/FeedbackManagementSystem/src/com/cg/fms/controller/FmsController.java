package com.cg.fms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.cg.fms.service.IFmsService;

@Controller
public class FmsController 
{
	@Autowired
	IFmsService fmsservice;

}
