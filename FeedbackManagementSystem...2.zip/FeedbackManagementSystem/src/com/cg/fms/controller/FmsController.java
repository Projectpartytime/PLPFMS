package com.cg.fms.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.service.IFmsService;

@Controller
public class FmsController 
{
	@Autowired
	IFmsService fmsservice;

	@RequestMapping(value="all", method=RequestMethod.GET)
	public String getAll(Model model)
	{
		model.addAttribute("my", new EmployeeBean());
		return "login";
	}
	@RequestMapping(value="feedbackform", method=RequestMethod.GET)
	public String inHome(Model model)
	{
		model.addAttribute("my", new FeedbackBean());
		return "FeedbackForm";
	}
	@RequestMapping(value="validatefeedbackdetail", method=RequestMethod.POST)
	public ModelAndView sucess(@Valid @ModelAttribute("my")FeedbackBean feedback,BindingResult result)
	{
		ModelAndView mv = new ModelAndView();
		if(result.hasErrors())
		{
			mv.setViewName("FeedbackForm");
		}
		else
		{
			/*try
			{*/
				if(fmsservice.validateTrainingIds(feedback.getTrainingCode()))
				{
					if(fmsservice.validateParticipantIds(feedback.getParticipantId()))
					{
						if(fmsservice.validateParticipantsEnrolled(feedback.getTrainingCode(), feedback.getParticipantId()))
						{
							if(fmsservice.validateFeedback(feedback.getTrainingCode(), feedback.getParticipantId()))
							{
								long id=fmsservice.insertFeedbackDetail(feedback);
								mv.setViewName("sucess");
							}
							else
							{
								mv.addObject("error1","Participant has already filled the Feedback Form");
								mv.setViewName("FeedbackForm");
							}			
						}
						else
						{
							mv.addObject("error2","Participant has not yet Enrolled");
							mv.setViewName("FeedbackForm");
						}
					}
					else
					{
						mv.addObject("error3","Participant ID does not exist");
						mv.setViewName("FeedbackForm");
					}
				}
				else
				{
					mv.addObject("error4","Training ID does not exist");
					mv.setViewName("FeedbackForm");
				}
				/*}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
				e.printStackTrace();
				mv.addObject("error","Invalid Input");
				mv.setViewName("Error");
			}*/
		}

		return mv;
	}
}
