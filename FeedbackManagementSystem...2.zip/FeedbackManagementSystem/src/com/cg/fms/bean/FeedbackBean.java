package com.cg.fms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
/* Name                                      Null?    Type
----------------------------------------- -------- -------------
TRAINING_CODE                                      NUMBER(5)
PARTICIPANT_ID                                     NUMBER(5)
FB_PRS_COMM                                        NUMBER(1)
FB_CLRFY_DBTS                                      NUMBER(1)
FB_TM                                              NUMBER(1)
FB_HAND_OUT                                        NUMBER(1)
FB_HW_SW_NTWRK                                     NUMBER(1)
COMMENTS                                           VARCHAR2(200)
SUGGESTIONS                                        VARCHAR2(200)
 */
@Entity
@Table(name="FEEDBACK_MASTER")
public class FeedbackBean 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="emp_seq")	
	@SequenceGenerator(name="emp_seq",sequenceName="emp_seq_eid")
	@Column(name="FEEDBACK_ID")
	private long feedbackId;
	
	@Column(name="TRAINING_CODE")
	@NotNull(message="TrainingCode cannot be blank")
	private Long trainingCode;
	
	@Column(name="PARTICIPANT_ID")
	@NotNull(message="ParticipantId cannot be blank")
	//@Pattern(message="ParticipantId should be in digits",regexp="[0-9][0-9][1-9]")
	private Long participantId;
	
	@Column(name="FB_PRS_COMM")
	private Integer presentComm;
	
	@Column(name="FB_CLRFY_DBTS")
	private Integer clarifyDoubt;
	
	@Column(name="FB_TM")
	private Integer timeManage;
	
	@Column(name="FB_HAND_OUT")
	private Integer handOut;
	
	@Column(name="FB_HW_SW_NTWRK")
	private Integer hardSoftNet;
	
	@Column(name="COMMENTS")
	@NotEmpty(message="comments cannot be left blank")
	private String comments;
	
	@Column(name="SUGGESTIONS")
	@NotEmpty(message="suggestions cannot be left blank")
	private String suggestions;
	
	
	public long getFeedbackId() {
		return feedbackId;
	}


	public void setFeedbackId(long feedbackId) {
		this.feedbackId = feedbackId;
	}


	public Long getTrainingCode() {
		return trainingCode;
	}


	public void setTrainingCode(Long trainingCode) {
		this.trainingCode = trainingCode;
	}


	public Long getParticipantId() {
		return participantId;
	}


	public void setParticipantId(Long participantId) {
		this.participantId = participantId;
	}


	public Integer getPresentComm() {
		return presentComm;
	}


	public void setPresentComm(Integer presentComm) {
		this.presentComm = presentComm;
	}


	public Integer getClarifyDoubt() {
		return clarifyDoubt;
	}


	public void setClarifyDoubt(Integer clarifyDoubt) {
		this.clarifyDoubt = clarifyDoubt;
	}


	public Integer getTimeManage() {
		return timeManage;
	}


	public void setTimeManage(Integer timeManage) {
		this.timeManage = timeManage;
	}


	public Integer getHandOut() {
		return handOut;
	}


	public void setHandOut(Integer handOut) {
		this.handOut = handOut;
	}


	public Integer getHardSoftNet() {
		return hardSoftNet;
	}


	public void setHardSoftNet(Integer hardSoftNet) {
		this.hardSoftNet = hardSoftNet;
	}


	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}


	public String getSuggestions() {
		return suggestions;
	}


	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}


	@Override
	public String toString() {
		return "FeedbackBean [feedbackId=" + feedbackId + ", trainingCode="
				+ trainingCode + ", participantId=" + participantId
				+ ", presentComm=" + presentComm + ", clarifyDoubt="
				+ clarifyDoubt + ", timeManage=" + timeManage + ", handOut="
				+ handOut + ", hardSoftNet=" + hardSoftNet + ", comments="
				+ comments + ", suggestions=" + suggestions + "]";
	}
	
}
