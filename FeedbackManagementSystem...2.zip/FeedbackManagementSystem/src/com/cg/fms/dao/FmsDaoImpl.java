package com.cg.fms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.bean.TrainingBean;

@Repository("fmsdao")
public class FmsDaoImpl implements IFmsDao 
{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public long insertFeedback(FeedbackBean feedback) {
		entitymanager.persist(feedback);
		entitymanager.flush();	
		return feedback.getFeedbackId();
	}
	
	@Override
	public List<Long> validateGetAllTrainingIds()
	{
		String q="SELECT tbean.trainingCode FROM TrainingBean tbean";
		Query query=entitymanager.createQuery(q);
		return query.getResultList();
	}
	
	@Override
	public List<Long> validateGetAllParticipantIds()
	{
		String q="SELECT ebean.employeeId FROM EmployeeBean ebean";
		Query query=entitymanager.createQuery(q);
		return query.getResultList();
	}
	@Override
	public List<Long> validateGetAllEnrolledTrainingIds()
	{
		String q="SELECT pbean.trainingCode FROM ParticipantEnrollmentBean pbean";
		Query query=entitymanager.createQuery(q);
		return query.getResultList();
	}
	@Override
	public List<Long> validateGetAllEnrolledParticipantIds(long trainingId) 
	{
		String q="SELECT pbean.participantId FROM ParticipantEnrollmentBean pbean WHERE pbean.trainingCode =:trainingId";
		Query query=entitymanager.createQuery(q);
		query.setParameter("trainingId", trainingId);
		return query.getResultList();
	}
	@Override
	public List<Long> validateGetAllFeedBackTrainingIds()
	{
		String q2="SELECT fbean.trainingCode FROM FeedbackBean fbean";
		Query query2=entitymanager.createQuery(q2);
		return query2.getResultList();
	}
	@Override
	public List<Long> validateGetAllFeedBackParticipanIds(long trainingId) 
	{
		String q6="SELECT fbean.participantId FROM FeedbackBean fbean WHERE fbean.trainingCode =:trainingId";
		Query query6=entitymanager.createQuery(q6);
		query6.setParameter("trainingId", trainingId);
		return query6.getResultList();
	}
	
}
