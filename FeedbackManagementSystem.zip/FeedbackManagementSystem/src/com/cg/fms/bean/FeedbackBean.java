package com.cg.fms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
/* Name                                      Null?    Type
----------------------------------------- -------- -------------
TRAINING_CODE                                      NUMBER(5)
PARTICIPANT_ID                                     NUMBER(5)
FB_PRS_COMM                                        NUMBER(1)
FB_CLRFY_DBTS                                      NUMBER(1)
FB_TM                                              NUMBER(1)
FB_HAND_OUT                                        NUMBER(1)
FB_HW_SW_NTWRK                                     NUMBER(1)
COMMENTS                                           VARCHAR2(200)
SUGGESTIONS                                        VARCHAR2(200)
 */
@Entity
@Table(name="FEEDBACK_MASTER")
public class FeedbackBean 
{
	@Column(name="TRAINING_CODE")
	private long trainingCode;
	
	@Column(name="PARTICIPANT_ID")
	private long participantId;
	
	@Column(name="FB_PRS_COMM")
	private int presentComm;
	
	@Column(name="FB_CLRFY_DBTS")
	private int clarifyDoubt;
	
	@Column(name="FB_TM")
	private int timeManage;
	
	@Column(name="FB_HAND_OUT")
	private int handOut;
	
	@Column(name="FB_HW_SW_NTWRK")
	private int hardSoftNet;
	
	@Column(name="COMMENTS")
	private String comments;
	
	@Column(name="SUGGESTIONS")
	private String suggestions;
	
	public long getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(long trainingCode) {
		this.trainingCode = trainingCode;
	}
	public long getParticipantId() {
		return participantId;
	}
	public void setParticipantId(long participantId) {
		this.participantId = participantId;
	}
	public int getPresentComm() {
		return presentComm;
	}
	public void setPresentComm(int presentComm) {
		this.presentComm = presentComm;
	}
	public int getClarifyDoubt() {
		return clarifyDoubt;
	}
	public void setClarifyDoubt(int clarifyDoubt) {
		this.clarifyDoubt = clarifyDoubt;
	}
	public int getTimeManage() {
		return timeManage;
	}
	public void setTimeManage(int timeManage) {
		this.timeManage = timeManage;
	}
	public int getHandOut() {
		return handOut;
	}
	public void setHandOut(int handOut) {
		this.handOut = handOut;
	}
	public int getHardSoftNet() {
		return hardSoftNet;
	}
	public void setHardSoftNet(int hardSoftNet) {
		this.hardSoftNet = hardSoftNet;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
}
