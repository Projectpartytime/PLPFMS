package com.cg.fms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/*Name                                      Null?    Type
----------------------------------------- -------- -------------------

COURSE_ID                                 NOT NULL NUMBER(5)
COURSE_NAME                                        VARCHAR2(50)
NO_OF_DAYS                                         NUMBER(5)
*/
@Entity
@Table(name="COURSE_MASTER")
public class CourseBean 
{
	@Id
	@Column(name="Course_ID")
	private long courseId;
	@Column(name="Course_Name")
	private String courseName;
	@Column(name="no_of_days")
	private long noOfDays;
	
	public long getCourseId() {
		return courseId;
	}
	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public long getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(long noOfDays) {
		this.noOfDays = noOfDays;
	}
	
}
