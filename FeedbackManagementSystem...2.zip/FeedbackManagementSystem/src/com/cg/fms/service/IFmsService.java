package com.cg.fms.service;

import com.cg.fms.bean.FeedbackBean;

public interface IFmsService
{
	boolean validateTrainingIds(long trainingId);
	boolean validateParticipantIds(long participantId);
	
	boolean validateParticipantsEnrolled(long trainingId, long participantId);
	
	
	boolean validateFeedback(long trainingId,long participantId);
	
	long insertFeedbackDetail(FeedbackBean feedback);
	
}
