package com.cg.fms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.dao.IFmsDao;



@Service("fmsservice")
@Transactional
public class FmsServiceImpl implements IFmsService
{
	@Autowired
	IFmsDao fmsdao;

	@Override
	public boolean validateTrainingIds(long trainingId)
	{
		List<Long> trainingCode = fmsdao.validateGetAllTrainingIds();
		for(long id:trainingCode)
		{
			if(id==trainingId)
			{
				return true;
			}
		}
		return false;
	}
	
	/*****************checking whether FacultyId is already exists or not********************/
	@Override
	public boolean validateParticipantIds(long participantId)
	{
		List<Long> empId = fmsdao.validateGetAllParticipantIds();
		for(long id:empId)
		{
			if(id==participantId)
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean validateParticipantsEnrolled(long trainingId, long participantId)
	{
		List<Long> tCode=fmsdao.validateGetAllEnrolledTrainingIds();
		List<Long> pCode=fmsdao.validateGetAllEnrolledParticipantIds(trainingId);
		
		for(long tcode:tCode)
		{
			for(long pcode:pCode)
			{
				if(tcode==trainingId && pcode==participantId)
				{
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public boolean validateFeedback(long trainingId, long participantId) 
	{
		List<Long> tCode=fmsdao.validateGetAllFeedBackTrainingIds();
		List<Long> pCode=fmsdao.validateGetAllFeedBackParticipanIds(trainingId);
		
		for(long tcode:tCode)
		{
			for(long pcode:pCode)
			{
				if(tcode==trainingId && pcode==participantId)
				{
					return false;
				}
			}
		}
		return true;
	}

	@Override
	public long insertFeedbackDetail(FeedbackBean feedback) {
		
		return fmsdao.insertFeedback(feedback);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}


