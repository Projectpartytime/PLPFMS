package com.cg.fms.dao;

public interface QueryMapper {
	
	/***Login***/
	String login="SELECT * FROM EMPLOYEE_MASTER WHERE EMPLOYEE_ID = ?";
	
	/*Admin Login Query */
	String Faculty_Skill_Maintenance="SELECT * FROM EMPLOYEE_MASTER WHERE skill_set=?";
	String Course_Maintenance="INSERT INTO COURSE_MASTER(Course_ID,Course_Name,no_of_days)VALUES(?,?,?)";
	String View_Feedback_Report_By_TrainingCode="SELECT participant_id,fb_prs_comm,fb_clrfy_dbts,fb_tm,fb_hand_out,fb_hw_sw_ntwrk,comments,suggestions FROM feedback_master WHERE training_code=?";
	String View_Feedback_Report_By_ParticipantId="SELECT fb_prs_comm,fb_clrfy_dbts,fb_tm,fb_hand_out,fb_hw_sw_ntwrk,comments,suggestions FROM feedback_master WHERE participant_id=?";	
	String selectsequence="SELECT course_seq.NEXTVAL FROM DUAL";
	String Course_Maintenance_display="SELECT * FROM COURSE_MASTER";
	String Course_Maintenance_Update="UPDATE COURSE_MASTER SET Course_Name=?,no_of_days=? WHERE Course_ID=?";
	String Course_Maintenance_Delete="DELETE FROM COURSE_MASTER WHERE Course_ID=?";
	
	/***Admin Validations***/
	String VALID_COURSE_ID="SELECT Course_ID FROM COURSE_MASTER";
	
	String VIEW_FEEDBACK_BY_TRAININGCODE="SELECT * FROM feedback_master WHERE training_code = ?";
	String VIEW_FEEDBACK_BY_PARTICIPANTCODE="SELECT * FROM feedback_master WHERE participant_id = ?";
	/*Participant login query */
	String VALID_FEEDBACK="SELECT * FROM feedback_master";
	
	String INSERT_PARTICIPANT_FB = "INSERT INTO feedback_master(training_code,participant_id,fb_prs_comm, fb_clrfy_dbts, fb_tm, fb_hand_out, fb_hw_sw_ntwrk, comments, suggestions) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
	String VALID_TRAINING_ID="SELECT Training_Code FROM TRAINING_MASTER";
	String VALID_PARTICIPANT_CODE="SELECT Participant_id FROM PARTICIPANT_ENROLLMENT WHERE Training_code =?";
	
	/*Coordinator*/
	String VALID_ENROLLMENT="SELECT * FROM participant_enrollment";
	String TRAINING_MASTER_INSERT_QUERY = "INSERT INTO Training_Master(training_code,course_code,faculty_code,start_date,end_date)  VALUES(?, ?, ?, ?, ?)";
	String PARTICIPANT_ENROLLMENT_INSERT_QUERY= "INSERT INTO PARTICIPANT_ENROLLMENT(Training_code,Participant_id) values(?, ?)";

	/**co-ordinator Validation**/
	String VALID_FACULTY_CODE="SELECT EMPLOYEE_ID FROM EMPLOYEE_MASTER";
	String VALID_DURATION="SELECT no_of_days FROM COURSE_MASTER WHERE Course_ID = ?";
}
