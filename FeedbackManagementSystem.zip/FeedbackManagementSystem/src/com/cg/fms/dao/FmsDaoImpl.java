package com.cg.fms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;

@Repository("fmsdao")
public class FmsDaoImpl implements IFmsDao 
{
	@PersistenceContext
	EntityManager entitymanager;
	
	public List<EmployeeBean> getEmployeeId(String skill)
	{
		String q1="FROM EmployeeBean emp WHERE emp.skillSet=:skill";
		TypedQuery<EmployeeBean> query1=entitymanager.createQuery(q1,EmployeeBean.class);
		query1.setParameter("skill", skill);
		return query1.getResultList();
	}

	@Override
	public long insertFeedback(FeedbackBean feedback) {
		entitymanager.persist(feedback);
		entitymanager.flush();	
		return feedback.getParticipantId();
	}

}
