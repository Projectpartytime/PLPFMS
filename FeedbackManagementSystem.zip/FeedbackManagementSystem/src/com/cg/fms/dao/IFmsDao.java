package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;

public interface IFmsDao 
{
	List<EmployeeBean> getEmployeeId(String skill);
	long insertFeedback(FeedbackBean feedback);
}
