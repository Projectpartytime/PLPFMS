package com.cg.fms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/*
 *  Name                                      Null?    Type
 ----------------------------------------- -------- ---------------------------

 TRAINING_CODE                                      NUMBER(5)
 PARTICIPANT_ID                                     NUMBER(5)
 */
@Entity
@Table(name="PARTICIPANT_ENROLLMENT")
public class ParticipantEnrollmentBean 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="emp_seq")	
	@SequenceGenerator(name="emp_seq",sequenceName="emp_seq_eid")
	@Column(name="ENROLL_ID")
	private long participantEnrollId;
	
	@Column(name="TRAINING_CODE")
	private long trainingCode;
	@Column(name="PARTICIPANT_ID")
	private long participantId;

	public long getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(long trainingCode) {
		this.trainingCode = trainingCode;
	}
	public long getParticipantId() {
		return participantId;
	}
	public void setParticipantId(long participantId) {
		this.participantId = participantId;
	}
	public long getParticipantEnrollId() {
		return participantEnrollId;
	}
	public void setParticipantEnrollId(long participantEnrollId) {
		this.participantEnrollId = participantEnrollId;
	}


}
